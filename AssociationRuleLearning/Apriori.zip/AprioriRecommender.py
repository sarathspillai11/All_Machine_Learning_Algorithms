import numpy as np
import pandas as pd
from apyori import apriori

# data = pd.read_excel(r'C:\Users\KPMG\ELMER\QRM2017_2019_new.xlsx')
# data.replace(r'\s+', np.nan, regex=True)
#
# observations = []
# for i in range(len(data)):
#     observations.append([str(data.values[i,j]) for j in range(len(data.columns))])
#
# associations = apriori(observations, min_length = 2, min_support = 0.2, min_confidence = 0.2, min_lift = 3)
#
#
# # min_support: The minimum support of relations (float)
# # min_confidence: The minimum confidence of relations (float)
# # min_lift: The minimum lift of relations (float)
# # min_length: The minimum number of items in a rule
# # max_length: The maximum number of items in a rule
#
# associations = list(associations)
#
# print(associations[0])

def AprioriRecomendationEngine(dataframe):
    observations = []
    for i in range(len(dataframe)):
        observations.append([str(dataframe.values[i, j]) for j in range(len(dataframe.columns))])

    #associations = apriori(observations, min_length=1, min_support=0.2, min_confidence=0.2, min_lift=1)
    associations = apriori(observations)
    associations = list(associations)
    return associations